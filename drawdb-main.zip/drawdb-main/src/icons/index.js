export { default as IconAddTable } from "./IconAddTable";
export { default as IconAddArea } from "./IconAddArea";
export { default as IconAddNote } from "./IconAddNote";
