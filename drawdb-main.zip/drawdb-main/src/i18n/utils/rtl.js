const rtlLanguages = ["ar", "he", "fa", "ps", "ur"];
export const isRtl = (language) => rtlLanguages.includes(language);
