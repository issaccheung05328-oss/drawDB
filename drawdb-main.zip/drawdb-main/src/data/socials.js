export const socials = {
  docs: "https://drawdb-io.github.io/docs",
  discord: "https://discord.gg/BrjZgNrmR6",
  twitter: "https://x.com/drawDB_",
  github: "https://github.com/drawdb-io/drawdb",
};
